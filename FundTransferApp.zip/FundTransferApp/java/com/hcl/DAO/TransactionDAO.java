package com.hcl.DAO;

import java.util.List;

import com.hcl.Exception.InsufficientBalanceException;
import com.hcl.model.Transaction;

public interface TransactionDAO {

	void transferFund(Transaction transaction) throws InsufficientBalanceException;

	List<Transaction> getStatement(String accountNo);

}

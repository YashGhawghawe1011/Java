package com.hcl.constants;

public enum TransactionType {
	
	DEBIT,CREDIT;

}

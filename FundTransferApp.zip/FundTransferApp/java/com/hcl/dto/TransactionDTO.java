package com.hcl.dto;

import java.util.Date;

import org.hibernate.validator.constraints.NotEmpty;

import com.hcl.constants.TransactionType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author yash.ghawghawe
 *
 */
@Getter
@Setter
@ToString
public class TransactionDTO {

	private int transactionId;
	@NotEmpty(message = "enter your account number")
	private String accountNo;
	@NotEmpty(message = "enter beneficiary account number")
	private String accountnoben;
	private Date date;
	private double amount;
	private TransactionType type;
	@NotEmpty(message = "enter transaction remarks")
	private String description;

}
